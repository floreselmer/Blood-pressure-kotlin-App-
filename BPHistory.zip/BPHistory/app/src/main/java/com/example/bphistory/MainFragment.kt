package com.example.bphistory

import android.os.Bundle
import android.view.*
import android.widget.Adapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_main.view.*
import java.util.*
import kotlin.random.Random as Random1

/**
 * A simple [Fragment] subclass.
 */
class MainFragment : Fragment() {
    private lateinit var appAdapter: AppAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val v = inflater.inflate(R.layout.fragment_main, container, false)
        setHasOptionsMenu(true)
        v.bp_list.setHasFixedSize(true)
        appAdapter=AppAdapter(BPLab.readings)
        v.bp_list.adapter=appAdapter
        return v
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.main_menu, menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.item_add -> {
               val random= Random()
                val systolic =100 + random.nextInt(50 )
                val diastolic = 60 + random.nextInt(40)
                val bp =BloodPressure(systolic,diastolic,Date())
                BPLab.readings.add(bp)
                appAdapter.notifyItemInserted(BPLab.readings.size -1 )
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


}
