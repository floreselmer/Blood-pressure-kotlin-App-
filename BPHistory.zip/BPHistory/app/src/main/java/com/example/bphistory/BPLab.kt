package com.example.bphistory

object BPLab {
    val readings = mutableListOf<BloodPressure>()
}