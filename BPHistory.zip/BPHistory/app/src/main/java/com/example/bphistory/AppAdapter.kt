package com.example.bphistory
import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import  androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_layout.view.*

class AppViewHolder(inflater:LayoutInflater,parent: ViewGroup) :
    RecyclerView.ViewHolder(inflater.inflate(R.layout.item_layout,parent,false))
{
    fun bind(bp:BloodPressure) {
itemView.text_reading.text=
    "${bp.systolic}/${bp.diastolic}-${BloodPressure.categories[bp.category()]}"
    itemView.text_date.text=bp.date.toString()
        }
    }




class AppAdapter(private var readings: MutableList<BloodPressure>) :
    RecyclerView.Adapter<AppViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
    val inflater:LayoutInflater=LayoutInflater.from(parent.context)
        return AppViewHolder(inflater,parent)
    }

    override fun getItemCount()= readings.size


    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
      holder.bind(readings[position])
    }


}